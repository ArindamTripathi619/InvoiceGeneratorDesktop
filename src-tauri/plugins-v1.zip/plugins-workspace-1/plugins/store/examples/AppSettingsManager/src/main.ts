window.addEventListener("DOMContentLoaded", () => {
  document.querySelector("#greet-form")?.addEventListener("submit", (e) => {
    e.preventDefault();
  });
});
